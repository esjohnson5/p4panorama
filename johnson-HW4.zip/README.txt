Eric Johnson

RANSAC creates an index of the points that are included in the maximum homography. 
This way, when I need to create the best homography with all the points I can 
simply iterate through the list. 

 